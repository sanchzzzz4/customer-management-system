First please install all dependencies by executing pip install -r requirements.txt

if requirements.txt is not working, install these modules individually
pip install pandas
pip install sqlite3
pip install prettytable


Then execute pre_start.py to create the tables required for the program

Now you are ready to run main.py